package common;

import java.util.Date;

public class DateUtils {
    private Date currentDate = new Date(2023 - 1900, 9, 28);

    public Date getCurrentDate() {
        return currentDate;
    }
}
