package common;

public enum Genre {
    FICTION,
    NON_FICTION,
    MYSTERY,
    ROMANCE,
    SCIENCE_FICTION,
    FANTASY,
    THRILLER,
    BIOGRAPHY,
    HISTORY,
    SELF_HELP,
    HORROR,
    ADVENTURE,
    POETRY
}